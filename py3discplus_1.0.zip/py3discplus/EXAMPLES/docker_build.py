#!/usr/bin/env python
import os
import shutil
import docker


PYTHON_SCRIPT = "fizzbuzz1.py"  # <1>
DOCKER_DIR = "docker_build"  # <2>
DOCKERFILE = "../DATA/Dockerfile"   # <3>

client = docker.from_env()  # <4>

os.makedirs(DOCKER_DIR, exist_ok=True)   # <5>
shutil.copy(DOCKERFILE, DOCKER_DIR)   # <6>
shutil.copy(PYTHON_SCRIPT, DOCKER_DIR)  # <7>

image, log_gen = client.images.build(  # <8>
    path=DOCKER_DIR,
    tag="python-fizz",
)

output = client.containers.run('python-fizz')  # <9>
print(output.decode())
print()

output = client.containers.run(image)  # <10>
print(output.decode())


