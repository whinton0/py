#!/usr/bin/env python
import docker

client = docker.from_env()  # <1>

result = client.containers.run("ubuntu", 'echo "Hello, world"')   # <2>
print(result, '\n')   # <3>
print(result.decode(), '\n')  # <4>
print('-' * 60)

result = client.containers.run("ubuntu", 'ls -l')  # <2>
print(result, '\n')   # <3>
print(result.decode(), '\n')  # <4>
