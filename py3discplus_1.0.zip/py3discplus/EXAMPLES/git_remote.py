#!/usr/bin/env python
import os
from git import Git, Repo

repo_dir = 'myproject'

repo = Repo(repo_dir)

os.chdir(repo_dir)

g = Git(repo)

g.remote('add', 'origin', 'https://github.com/jstrickler/myproject.git')  # <1>

g.push('-u', 'origin', 'master')  # <2>


