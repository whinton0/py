#!/usr/bin/env python
import os
import shutil
from git import Git, Repo

repo_dir = 'newproject'

r = Repo.init(repo_dir)  # <1>
os.chdir(repo_dir)

file_to_add = 'creating_dicts.py'
g = Git(r)  # <2>
shutil.copy('../' + file_to_add, ".")  # <3>

g.add(file_to_add)  # <4>
g.commit(file_to_add, message="initial commit")  # <5>
print(g.log())  # <6>
