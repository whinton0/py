#!/usr/bin/env python
# (c) 2017 John Strickler
#
def function_c():
    print("Hello from function_c")
