#!/usr/bin/env python
import os
from git import Git, Repo

repo_dir = 'myproject'

repo = Repo(repo_dir)

os.chdir(repo_dir)

g = Git(repo)
print(g.log())  # <1>
print('-' * 60)
print(g.log('unicode.py'))  # <2>
print('-' * 60)
print(g.log('fizzbuzz1.py'))  # <2>
