#!/usr/bin/env python
#

class OpenableThing():
    def __init__(self):
        print("Creating an OpenableThing")

    def __enter__(self):  # <1>
        print("Entering block")
        return self

    def __exit__(self, exc_type, value, traceback):  # <2>
        print("Leaving block")
        if exc_type is not None:
            print('*********************** EXCEPTION ************************')
            print("exception type:", exc_type)  # all None unless Exception occurs
            print("value:", value)
            print("traceback:", traceback)
            print('*************** * *******************************************')
        else:
            self.close()
        return True  # <3>

    def close(self):
        print("Closing")

    def hello(self):
        print("Hello from an OpenableThing")

with OpenableThing() as ot:  # <4>
    print("In the context...")
    ot.hello()  # <5>

print('-' * 60)

with OpenableThing() as ot:  # <4>
    print("In the context....")
    raise Exception("Oh nooooooo")  # <6>
