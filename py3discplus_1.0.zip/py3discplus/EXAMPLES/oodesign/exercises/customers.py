class Customer:

    def __init__(self, first_name, last_name, age, street, city, state, zip):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.street = street
        self.city = city
        self.state = state
        self.zip = zip

    def __str__(self):
        fmt = "{} {}\n{}\n{}, {} {}"
        return fmt.format(self.first_name, self.last_name, self.street,
                          self.city, self.state, self.zip)
