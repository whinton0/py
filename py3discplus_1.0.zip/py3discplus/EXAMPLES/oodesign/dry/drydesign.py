#!/usr/bin/env python3
def do_something(an_object):
    do_not_allow_none(an_object)
    # business logic would go here


def do_something_else(an_object):
    do_not_allow_none(an_object)
    # business logic would go here


def do_not_allow_none(an_object):
    if an_object is None:
        raise TypeError("NoneType is not allowed")
