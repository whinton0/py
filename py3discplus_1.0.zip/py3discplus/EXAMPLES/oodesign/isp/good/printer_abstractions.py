import os
from abc import ABC, abstractmethod


class Printable(ABC):
    @abstractmethod
    def print_it(self):
        pass


class Scannable(ABC):
    @abstractmethod
    def scan_it(self, file_name):
        pass


class Faxable(ABC):
    @abstractmethod
    def fax_it(self, fax_number):
        pass


class Emailable(ABC):
    @abstractmethod
    def email_it(self, email_address):
        pass
