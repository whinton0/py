from printer import Printer


class PrintAndScan(Printer):
    def __init__(self, data):
        self.data = data

    def print_it(self):
        print("Printing")
        print(self.data)

    def scan_it(self, file_name):
        print("Scanning to:", file_name)
        with open(file_name, "w") as scan_to:
            scan_to.write(self.data)

    def fax_it(self, fax_number):
        raise NotImplementedError("Faxing Not Supported")

    def email_it(self, email_address):
        raise NotImplementedError("Emailing Not Supported")
