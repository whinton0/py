#!/usr/bin/env python3
def words(text):
    words = []
    for each_line in [line for line in text.split("\n")]:
        words.extend(each_line.split())
    return words


def read_file(filename):
    with open(filename) as the_file:
        text = the_file.read()
    return text


def print_iterable(an_iterable, per_line=1):
    for counter, value in enumerate(an_iterable):
        print(value, end=" ")
        if counter % per_line == per_line - 1:
            print()


def main():
    result = read_file("declaration_of_independance.txt")
    data = words(result)
    print_iterable(data, 10)


if __name__ == "__main__":
    main()
