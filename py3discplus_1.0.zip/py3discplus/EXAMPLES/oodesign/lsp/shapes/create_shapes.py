#!/usr/bin/env python3
import dataclasses
import sys

from circle import Circle
from square import Square
from rectangle import Rectangle


def main():
    shapes = [Circle("Circle 1", 10),
              Square("Square 1", 5),
              Rectangle("Rectang1e 1", 5, 10)]

    for shape in shapes:
        print(shape)
        print("Area:", shape.area(), "Perimeter:", shape.perimeter())
        print("*" * 50)

    try:
        shapes[1].width = 88
    except dataclasses.FrozenInstanceError as fie:
        print("Frozen Instance Error", fie, file=sys.stderr)


if __name__ == "__main__":
    main()
