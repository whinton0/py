#!/usr/bin/env python3
from dataclasses import dataclass

from shape import Shape


@dataclass(frozen=True)
class Rectangle(Shape):
    length: int
    width: int

    def __str__(self):
        fmt = "{}  Length:{} Width:{}"
        return fmt.format(super().__str__(), self.length,
                          self.width)

    def area(self):
        return self.length * self.width

    def perimeter(self):
        return 2 * self.length + 2 * self.width
