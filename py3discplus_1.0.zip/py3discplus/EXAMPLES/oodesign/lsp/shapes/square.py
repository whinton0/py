#!/usr/bin/env python3
from dataclasses import dataclass

from rectangle import Rectangle


@dataclass(frozen=True)
class Square(Rectangle):
    # implemented with __init__ otherwise using type hinting would require
    # the width be passed as an argument to the constructor also
    def __init__(self, name, length):
        super().__init__(name, length, length)
