#!/usr/bin/env python
import docker

client = docker.from_env()  # <1>
result = client.containers.run("hello-world")   # <2>
print(result.decode(), '\n')  # <3>
