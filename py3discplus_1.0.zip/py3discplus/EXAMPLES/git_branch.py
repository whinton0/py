#!/usr/bin/env python
import os
from git import Git, Repo

repo_dir = 'myproject'

repo = Repo(repo_dir)

os.chdir(repo_dir)

g = Git(repo)

g.checkout('-b', 'myfeature')  # <1>

g.add('tyger.py')  # <2>
g.commit('tyger.py', message='new file')

