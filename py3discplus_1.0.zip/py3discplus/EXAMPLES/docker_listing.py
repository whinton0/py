#!/usr/bin/env python
import docker

client = docker.from_env()  # <1>

client.containers.run('ubuntu', 'sleep 30', detach=True)
client.containers.run('ubuntu', 'sleep 30', detach=True)
client.containers.run('ubuntu', 'sleep 30', detach=True)

for container in client.containers.list():
    print(container)
