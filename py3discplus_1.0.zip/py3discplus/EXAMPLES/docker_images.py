#!/usr/bin/env python
import docker

client = docker.from_env()  # <1>

for image in client.images.list():  # <2>
    print(image.tags, image.short_id)  # <3>

result = client.images.pull("python")  # <4>
print(result)  # <5>

