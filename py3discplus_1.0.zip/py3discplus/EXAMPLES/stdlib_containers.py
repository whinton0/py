#!/usr/bin/env python
from collections import Counter, defaultdict, deque, namedtuple, OrderedDict

# Counter
with open('../DATA/words.txt') as words_in:
    word_counter = Counter(line[0] for line in words_in)  # <1>

print("a: {} q: {} x: {}".format(
    word_counter['a'], word_counter['q'], word_counter['x']  # <2>
))

print(word_counter.most_common(10))  # <3>
print('-' * 60)

# defaultdict
fruits = ["pomegranate", "cherry", "apricot", "date", "apple",
          "lemon", "kiwi", "orange", "lime", "watermelon", "guava",
          "papaya", "fig", "pear", "banana", "tamarind", "persimmon",
          "elderberry", "peach", "blueberry", "lychee", "grape"]

fruit_by_first = defaultdict(list)  # <4>

for fruit in fruits:
    fruit_by_first[fruit[0]].append(fruit)  # <5>

for letter, fruits in sorted(fruit_by_first.items()):
    print(letter, fruits)
print('-' * 60)

# deque
d = deque()  # <6>
for c in 'abcdef':
    d.append(c)   # <7>
print(d)
for c in 'ghijkl':
    d.appendleft(c)  # <8>
print(d)
d.extend('mno')  # <9>
print(d)
d.extendleft('pqr')  # <10>
print(d)
print(d[9])
print(d.pop(), d.popleft())  # <11>
print(d)
print('-' * 60)


# namedtuple
President = namedtuple('President', 'first_name, last_name, party')  # <12>
p = President('Theodore', 'Roosevelt', 'Republican')  # <13>
print(p, len(p))
print(p[0], p[1], p[-1])
print(p.first_name, p.last_name, p.party)  # <14>

p = President(last_name='Lincoln', party='Republican', first_name='Abraham')
print(p)
print(p.first_name, p.last_name)
print('-' * 60)

# OrderedDict
od = OrderedDict()  # <15>
od['alpha'] = 10
od['beta'] = 20
od['gamma'] = 30
od['delta'] = 40
od['eta'] = 50

for key, value in od.items():
    print(key, value)  # <16>
