#!/usr/bin/env python
import os
from git import Git, Repo

repo_dir = 'myproject'  # <1>

repo = Repo(repo_dir)   # <2>

os.chdir(repo_dir)  # <3>

g = Git(repo)   # <4>
print(g.status())  # <5>


