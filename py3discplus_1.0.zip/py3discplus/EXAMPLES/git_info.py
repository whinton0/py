#!/usr/bin/env python
from git import Repo

repo_dir = 'myproject'

repo = Repo(repo_dir)

print("Untracked files:", repo.untracked_files, '\n')  # <1>

print("Branches:")
for branch in repo.branches:  # <2>
    print(branch.name, branch.path)
print()

print(repo.is_dirty(), '\n')  # <3>

print(repo.remotes)  # <4>
