#!/usr/bin/env python
from git import Repo

repo = Repo('myproject')

for tag in repo.tags:  # <1>
    print(tag.name)
